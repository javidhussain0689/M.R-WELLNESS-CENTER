self.addEventListener('install', (e)=>{
  e.waitUntil(caches.open('mrw-cache-v1').then(cache=>cache.addAll([
    './','./index.html','./style.css','./manifest.webmanifest','./service-worker.js'
  ])));
});
self.addEventListener('fetch', (e)=>{
  e.respondWith(caches.match(e.request).then(resp=> resp || fetch(e.request)));
});