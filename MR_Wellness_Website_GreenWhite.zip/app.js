
// PWA install
if('serviceWorker' in navigator){
  window.addEventListener('load',()=>{
    navigator.serviceWorker.register('./sw.js');
  });
}
// Simple phone CTA
function callNow(){ window.location.href='tel:+917330649897'; }
function whatsapp(){ window.open('https://wa.me/917330649897','_blank'); }
