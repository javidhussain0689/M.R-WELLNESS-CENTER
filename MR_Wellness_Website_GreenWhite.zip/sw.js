
self.addEventListener('install', (e)=>{
  e.waitUntil(caches.open('mrw-v1').then(c=>c.addAll([
    './','./index.html','./about.html','./services.html','./contact.html',
    './style.css','./app.js','./manifest.webmanifest'
  ])));
});
self.addEventListener('fetch', (e)=>{
  e.respondWith(caches.match(e.request).then(r=> r || fetch(e.request)));
});
